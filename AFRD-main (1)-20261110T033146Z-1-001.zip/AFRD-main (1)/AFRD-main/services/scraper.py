import os
import requests


class ReviewScraper:
    def __init__(self, product_url):
        self.product_url = product_url
        self.api_key = os.getenv("SERPAPI_KEY")

        if not self.api_key:
            raise ValueError("SERPAPI_KEY not found. Set it in environment variables.")

    def scrape_reviews(self, max_reviews=5):
        query = f"reviews {self.product_url}"

        params = {
            "engine": "google",
            "q": query,
            "api_key": self.api_key,
            "num": 10
        }

        try:
            response = requests.get(
                "https://serpapi.com/search", params=params, timeout=30
            )
            data = response.json()
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Could not reach SerpAPI: {e}")
        except ValueError:
            raise ValueError("SerpAPI returned an unreadable response.")

        # Surface real API problems (bad key, no credits, ...) instead of
        # silently showing the sample reviews. "No results" is not an error.
        error = data.get("error")
        if error and "hasn't returned any results" not in error:
            raise ValueError(f"SerpAPI error: {error}")

        reviews = []

        for result in data.get("organic_results", []):
            snippet = result.get("snippet")
            if snippet:
                reviews.append({
                    "content": snippet,
                    "source": result.get("link")
                })
            if len(reviews) >= max_reviews:
                break

        # Fallback
        if not reviews:
            reviews = [
                {"content": "Amazing product, works perfectly and arrived fast."},
                {"content": "Good quality, but delivery was slow."},
                {"content": "Terrible product. Reviews seem fake and repetitive."},
                {"content": "Five stars! Highly recommended to everyone."},
                {"content": "Not worth the money, feels low quality."}
            ]

        return reviews