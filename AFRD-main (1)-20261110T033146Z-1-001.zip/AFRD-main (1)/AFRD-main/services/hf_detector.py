import os

# ---------------------------------------------------------------------------
# Fake review detector
#
# Default: runs a model LOCALLY with the `transformers` library. This is free
# and needs no API key or credits. The model downloads once (~270 MB) the first
# time it is used, then is cached.
#
# Optional: set USE_HF_API=1 in .env to use the Hugging Face hosted API instead
# (needs HF_API_KEY and Hugging Face credits).
# ---------------------------------------------------------------------------

CANDIDATE_LABELS = ["fake review", "genuine review"]

_local_classifier = None  # loaded once, reused for every request


def _get_local_classifier(model_name):
    global _local_classifier
    if _local_classifier is None:
        try:
            from transformers import pipeline
        except ImportError:
            raise ValueError(
                "The 'transformers' library is not installed. In your terminal "
                "run: pip install transformers torch   then restart the app."
            )
        _local_classifier = pipeline("zero-shot-classification", model=model_name)
    return _local_classifier


class FakeReviewDetector:
    def __init__(self):
        self.use_api = os.getenv("USE_HF_API", "0") == "1"

        if self.use_api:
            self.api_key = os.getenv("HF_API_KEY")
            if not self.api_key:
                raise ValueError("HF_API_KEY not found in environment variables.")
            self.model = os.getenv("HF_MODEL", "facebook/bart-large-mnli")
            self.API_URL = (
                "https://router.huggingface.co/hf-inference/models/" + self.model
            )
            self.headers = {"Authorization": f"Bearer {self.api_key}"}
        else:
            self.model = os.getenv("LOCAL_MODEL", "typeform/distilbert-base-uncased-mnli")

    def predict(self, texts):
        """
        texts: a cleaned review string.
        Returns a list of lists, highest score first:
            [[{"label": "fake review", "score": 0.7},
              {"label": "genuine review", "score": 0.3}]]
        Raises ValueError with a readable message on failure.
        """
        if self.use_api:
            return self._predict_api(texts)
        return self._predict_local(texts)

    # ----------------------------- local -----------------------------
    def _predict_local(self, text):
        # Make sure we always hand the model one non-empty string
        if isinstance(text, (list, tuple)):
            text = " ".join(str(t) for t in text)
        text = str(text or "").strip()[:1500]
        if not text:
            raise ValueError("The review text was empty, so it could not be analyzed.")

        classifier = _get_local_classifier(self.model)
        try:
            out = classifier(text, candidate_labels=CANDIDATE_LABELS)
        except Exception as e:
            raise ValueError(
                f"Local model error: {e} (text length={len(text)}, "
                f"starts with: {text[:60]!r})"
            )
        if isinstance(out, list):  # some versions wrap a single result in a list
            out = out[0]
        return [[
            {"label": l, "score": float(s)}
            for l, s in zip(out["labels"], out["scores"])
        ]]

    # ------------------------------ API ------------------------------
    def _predict_api(self, texts):
        import requests

        payload = {
            "inputs": texts,
            "parameters": {"candidate_labels": CANDIDATE_LABELS},
        }

        try:
            response = requests.post(
                self.API_URL, headers=self.headers, json=payload, timeout=60
            )
        except requests.exceptions.RequestException as e:
            raise ValueError(f"Could not reach Hugging Face: {e}")

        if response.status_code in (401, 403):
            raise ValueError(
                f"Hugging Face rejected your token (HTTP {response.status_code}). "
                "Check HF_API_KEY in your .env - it should start with 'hf_'."
            )
        if response.status_code == 402:
            raise ValueError(
                "Hugging Face needs pre-paid credits for this request (HTTP 402)."
            )
        if response.status_code == 503:
            raise ValueError(
                "The Hugging Face model is still loading. Wait about 30 "
                "seconds and try again."
            )
        if response.status_code != 200:
            raise ValueError(
                f"Hugging Face error (HTTP {response.status_code}) "
                f"for model '{self.model}': {response.text[:300]}"
            )

        data = response.json()

        if isinstance(data, dict) and "labels" in data and "scores" in data:
            data = [
                {"label": l, "score": sc}
                for l, sc in zip(data["labels"], data["scores"])
            ]
        if data and isinstance(data, list) and isinstance(data[0], dict):
            data = [data]
        return data